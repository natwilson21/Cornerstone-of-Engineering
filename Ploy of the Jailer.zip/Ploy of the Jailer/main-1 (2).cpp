#include <iostream>
#include <cmath>
#include <ctime>
#include <cstdlib>

using namespace std;

int main() {
    //Introduction
    cout << "Welcome, it's time to decide your fate. " << endl <<
            "Win freedom by rolling a die on your gold coins or" << endl <<
            "Lose and end up as dragon food by rolling on a silver coin" << endl <<
            "Let's begin!"<< endl;
    int game = 1;
    int win = 0;
    int loss = 0;
    while (win !=3 && loss !=3){
        cout << "Game " << game << endl;

        //Jailer announces where they randomly placed their silver coin
        srand(time(0));
        int silverCoin = rand() % 20 + 1;
        cout << endl;
        cout << "Jailer chose to put their silver coin on slot " << silverCoin << endl;
        cout << endl;

        //User places two gold coins
        int goldCoin1 = 0;
        int goldCoin2 = 0;
        cout << "Jailer gives you two gold coins to place anywhere on the game board (1-20)" << endl;
        cin >> goldCoin1;
        cin >> goldCoin2;
        if (goldCoin1 > 21) {
            cout << goldCoin1 << " is too big, pick a number between 1-20" << endl;
            cin >> goldCoin1;
        }
        if (goldCoin2 > 21) {
            cout << goldCoin2 << " is too big, pick a number between 1-20" << endl;
            cin >> goldCoin2;
        }
        if (goldCoin1 == silverCoin) {
            cout << silverCoin << " is already take, please pick another spot on the board" << endl;
            cin >> goldCoin1;
        }
        if (goldCoin2 == silverCoin) {
            cout << silverCoin << " is already take, please pick another spot on the board" << endl;
            cin >> goldCoin2;
        }

        //Dice Rolls
        int userDie = 0;
        int userToken = 0;
        int roundNum = 1;
        cout << endl;

        while ((userToken != silverCoin) || (userToken != goldCoin1) || (userToken != goldCoin2)) {
            userDie = (rand() % 6 + 1);
            userToken = userToken + userDie;

            if (userToken > 20) {
                cout << "Round : " << roundNum << endl;
                cout << "You rolled a " << userDie << endl;
                userToken = userToken - 20;
                cout << "Your token is in spot " << userToken << endl;
                cout << endl;
                roundNum++;
            }
            else {
                cout << "Round : " << roundNum << endl;
                cout << "You rolled a " << userDie << endl;
                cout << "Your token is in spot " << userToken << endl;
                cout << endl;
                roundNum++;
            }
            if (userToken == silverCoin) {
                cout << "You lose!" << endl;
                loss++;
                if (loss == 3) {
                    cout << "You lost, you now become dragon food" << endl;
                    break;
                }
                break;
            }
            if ((userToken == goldCoin1) || (userToken == goldCoin2)) {
                cout << "You win!" << endl;
                win++;
                if (win == 3) {
                    cout << "You WON! FREEEDOMMMM!!!" << endl;
                    break;
                }
                break;
            }
            cout << endl;
            }
        game++;

        }
}
