RL = readlines('wordlist.csv');
randomWord = RL(randi(20) , 1);
userguesses = zeros(6,5);
for i = 1:1:6
userguess = input('\n Guess the random word: ', 's');
userguesses(1,:) = char(userguess);
colorText(userguess, randomWord)
if userguess == randomWord
fprintf('\n you got it\n')
break
end
if i==6
fprintf("\n" + "Game over \n")
fprintf("The correct answer was %s ", randomWord);
break
end
end
function colorText(guessword , randomWord)
correctArray(5) = 0;
guessArray(5) = 0;
guess = char(guessword);
random = char(randomWord);
for x = 1:1:5
C = strcmp(guess(x),random(x));
if C ==1
correctArray(x)=1;
guessArray(x)=correctArray(x);
end
end
for x = 1:1:5
for y = 1:1:5
D = strcmp(guess(x), random(y));
if D==1 && correctArray(y)==0 && guessArray(x)==0
guessArray(x)=2;
correctArray(y)=guessArray(x);
end
end
end
for x = 1:5
if guessArray(x)==0
cprintf('text', " " + guess(x))
end
if guessArray(x) == 1
cprintf('green'," " + guess(x))
end
if guessArray(x) == 2
cprintf('magenta', " " + guess(x))
end
end
end