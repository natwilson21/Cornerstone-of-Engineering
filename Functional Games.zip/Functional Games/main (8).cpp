#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <cmath>

using namespace std;
//functions
void enemyhit(int& soldierHP, int& poisonstat, int& enemyCH);
void attack(int& enemyCH, int& poisonstat);
void heal(int& healstat, int& soldierHP);
void befriend(int& friendstat, int& ripenemy);
void poison(int& poisonstat);
void stats(int& soldierHP, int& ripsoldier, int& enemyCH, int& ripenemy, int& friendstat, int& poisonstat, int& enemyRH);
int main() {
    //Welcome player to the game
    cout << "Welcome to Moral Clash soldier, I am your commanding officer." << endl;
    cout << "Gather your weapons and get ready for battle. We are at war..." << endl;
    cout << "'Remember in war, there is no prize for the runner-up' - General Omar Bradley \n" << endl;
    cout << "Are you ready recruit? (y/n)" << endl;
    string ready;
    cin >> ready;
    if (ready == "y" || ready == "Y") {
        cout << "Good. Get some rest, I will see you in the morning... \n" << endl;
    }
    else if (ready == "n" || ready == "n"){
        cout << "No? Too bad recruit this is what you signed up for. I'll see you in the morning.\n" << endl;
    }
    //initialize all variables
    int enemyHP[3][3] = {
            {40, 45, 47},
            {43, 48, 53},
            {50, 55, 60},
    };
    //enemy healh
    int enemyCH;
    int ripenemy = 0;
    //soldier health
    int soldierHP = 25;
    int ripsoldier = 0;
    //soldier actions
    int choice;
    //poison stat
    int poisonstat = 0;
    //friendstat
    int friendstat = 0;
    //healstat
    int healstat = 0;
    //rand num generator
    srand(time(0));
    //Keep soldier updated p1
    cout << "Wake up soldier!" << endl;
    //rand enemy HP
    int randHProw = rand() % 3;
    int randHPcolumn = rand() % 3;
    //enemy current health
    int enemyRH;
    enemyRH = enemyHP[randHProw][randHPcolumn];
    enemyCH = enemyRH;
    //if user does not input 1,2,3, or 4
    string error = "Soldier what do you not understand? You can attack(1), heal(2), befriend them(3), or poison(4) the enemy";
    //Loop game until enemies are defeated, friended, or soldier dies.
    //while enemy health is not 0/dead
    while (enemyCH > 0 || soldierHP > 0 || friendstat < 10) {
        //enemy attacks, user chooses what action to do as revenge
        cout << "The enemy has attacked, ouch!" << endl;
        cout << "You can: attack(1), heal(2), befriend them(3), or poison them(4). What would you like to do? "<< endl;
        cin >> choice;
        while (choice > 4) {
            cout << error << endl;
            cin >> choice;
        }
        //switch cases
        switch (choice) {
            case 1: {
                //attack function
                attack(enemyCH, poisonstat);
                enemyhit(soldierHP, poisonstat, enemyCH);
                stats(soldierHP, ripsoldier, enemyCH, ripenemy, friendstat, poisonstat, enemyRH);
                break;
            }
            case 2: {
                //heal function
                heal(healstat, soldierHP);
                enemyhit(soldierHP, poisonstat, enemyCH);
                stats(soldierHP, ripsoldier, enemyCH, ripenemy, friendstat, poisonstat, enemyRH);
                break;
            }
            case 3: {
                //befriend function
                befriend(friendstat, ripenemy);
                enemyhit(soldierHP, poisonstat, enemyCH);
                stats(soldierHP, ripsoldier, enemyCH, ripenemy, friendstat, poisonstat, enemyRH);
                break;
            }
            case 4: {
                //poison function
                poison(poisonstat);
                enemyhit(soldierHP, poisonstat, enemyCH);
                stats(soldierHP, ripsoldier, enemyCH, ripenemy, friendstat, poisonstat, enemyRH);
                break;
            }
        } //end switch
        if (ripsoldier >= 1) {
            break;
        }
        if (ripenemy >= 1) {
            break;
        }
    }//end while (enemyCH >=0)

} //end while (ripenemy != endgame)

//attack function
    void attack(int& enemyCH, int& poisonstat) {
        int attackvalues[6] = {4, 6, 6, 8, 10, 10};
        int randvalattack = attackvalues[rand() % 6];
        enemyCH = enemyCH - randvalattack;
    }
//heal function
    void heal(int& healstat, int& soldierHP){
    //rand value (3-8) to add to in healstat
    int randhealstat = rand() % 9 + 1;
    healstat = healstat + randhealstat;
    soldierHP = soldierHP + healstat;
    if (soldierHP > 25) {
        soldierHP = 25;
        cout << "You are fully healed, soldier." << endl;
    }
}
//befriend function
    void befriend(int& friendstat, int& ripenemy){
    //rand value to add to int friendstat
    int randfriendval = rand() % 4 + 1;
    friendstat = friendstat + randfriendval;
    if (friendstat >= 10) {
        cout << "Enemies to Friends <3" << endl;
        ripenemy++;
        cout << "You have successfully befriended the enemy." << endl;
        cout << "Great job Recruit!" << endl;
    }
    else if (friendstat >= 5 && friendstat <= 9) {
        cout << "Definitely getting closer towards friendship." << endl;
    }
    else {
        cout << "I think we are slowly getting along..." << endl;
    }
}
//Poison function
    void poison(int& poisonstat) {
    //rand val to add to int poisonstat
    int randpoisonval = rand() % 6 + 2;
    poisonstat = poisonstat + randpoisonval;
    if (poisonstat > 0 && poisonstat < 5) {
        cout << "The enemy got a little taste of my poison!" << endl;
    }
    else if (poisonstat >= 5 && poisonstat < 8) {
        cout << "The enemy has been fully poisoned mwahaha" << endl;
    }
    else if (poisonstat >= 8){
        cout << "The enemy is coughing up a lung, the poison seems to be working. " << endl;
    }
    else if (poisonstat >= 10) {
        cout << "The amount of poison in the enemies blood is astonishing, how are they still standing?" << endl;
    }

    //cout << poisonstat << endl;
}
//enemy can fight too
    void enemyhit(int& soldierHP, int& poisonstat, int& enemyCH){
    //rand val that decreases soldier HP
    int randhitval = rand() % 7 + 2;
    soldierHP = soldierHP - randhitval;
    if (poisonstat > 0) {
        enemyCH = enemyCH - poisonstat;
        poisonstat--;
    }
}
//stats
    void stats(int& soldierHP, int& ripsoldier, int& enemyCH, int& ripenemy, int& friendstat, int& poisonstat, int& enemyRH){
    //keep player updated pt2
    if (soldierHP > 0) {
        cout << "Recruit, your health report is " << soldierHP << " out of 25" << endl;
    }
    if ((soldierHP < 10 && soldierHP > 5) && ripsoldier < 1 && ripenemy < 1 && (enemyCH > 0 && soldierHP > 0)) {
        cout << "Soldier take caution! Your health is below 10." << endl;
    }
    else if ((soldierHP <= 5 && ripsoldier < 1 && ripenemy < 1 && (enemyCH > 0 && soldierHP > 0))){
        cout << "Seriously recruit? Don't be reckless, your health is super low!" << endl;
    }
    //keep player updated pt3
    if (enemyCH <= 10 && ripenemy < 1 && ripsoldier < 1 && (enemyCH > 0 && soldierHP > 0)) {
        cout << "Your enemy is super weak!" << endl;
    }
    //keep player updated pt4
    if ((enemyCH <= 15 && enemyCH > 10) && ripenemy < 1 && ripsoldier < 1 && (enemyCH > 0 && soldierHP > 0)) {
        cout << "Your enemy is hurt, keep fighting Recruit!" << endl;
    }
    //soldier down scenario
    if (soldierHP <= 0 && enemyCH > 0) {
        ripsoldier++;
        cout << "soldier down!" << endl;
        cout << "Do you want to try again recruit? (y/n)" << endl;
        string playagain;
        cin >> playagain;
        if (playagain == "y" || playagain == "Y" ){
            ripsoldier = 0;
            cout << "The medic has cleared you, get up and go soldier." << endl;
            soldierHP = 25;
            enemyCH = enemyRH;
        }
        else if (playagain == "n" || playagain == "N" ) {
            cout << "Better luck next time." << endl;
        }
    }
    //enemy down scenario
    else if (enemyCH <= 0 && soldierHP > 0) {
        cout << "You have successful taken down the enemy." << endl;
        cout << "Good Job Recruit!" << endl;
        ripenemy = 2;
    }
   //both soldier and enemy are down scenario
    else if (enemyCH <= 0 && soldierHP <= 0) {
        cout << "Took each other out at the same time, next time stay alive to see your enemy fall." << endl;
        ripsoldier++;
        cout << "Do you want to try again recruit? (y/n)" << endl;
        string playagain;
        cin >> playagain;
        if (playagain == "y" || playagain == "Y" ){
            ripsoldier = 0;
            cout << "The medic has cleared you, you're all set to go." << endl;
            soldierHP = 25;
            enemyCH = enemyRH;
        }
        else if (playagain == "n" || playagain == "N" ) {
            cout << "Remember, 'if the enemy is in range, so are you.' - Murphy's Law of Combat" << endl;
            cout << "Better luck next time." << endl;
        }
    }

}